//
//  Assets.swift
//  tutorial2
//
//  Created by Yuma Antoine Decaux on 14/07/17.
//  Copyright © 2017 antoxicon. All rights reserved.
//

import SceneKit

var steps = [SCNAudioSource]()

func loadSteps(){
	for i in 1...10{
		let source = SCNAudioSource(fileNamed: "wood_\(i).mp3")!
		source.loops = false
		steps.append(source)
	}
}
