//
//  GameViewController.swift
//  tutorial2
//
//  Created by Yuma Antoine Decaux on 13/07/17.
//  Copyright (c) 2017 antoxicon. All rights reserved.
//

import SceneKit

enum Arrow:UInt16{
	case Down = 125
	case UP = 126
	case Left = 123
	case Right = 124

	var vector:float2{
		switch self{
		case .Down: return float2(0, 1)
		case .UP: return float2(0, -1)
		case .Left: return float2(-1, 0)
		case .Right: return float2(1, 0)
		}
	}
}

class GameViewController: NSViewController, SCNSceneRendererDelegate {
	var direction = float2(0, 0)
	let cricket = SCNNode()
	let cricketSource = SCNAudioSource(fileNamed: "crickets.mp3")!
	let ambient = SCNNode()
	let ambientSource = SCNAudioSource(fileNamed: "wind.mp3")!
	let chime = SCNNode()
	let chimeSource = SCNAudioSource(fileNamed: "chime.mp3")!
	let cameraNode = SCNNode()
	@IBOutlet weak var gameView: GameView!

	override func awakeFromNib(){
		super.awakeFromNib()

		// create a new scene
		let scene = SCNScene()

		// create and add a camera to the scene
		cameraNode.camera = SCNCamera()
		scene.rootNode.addChildNode(cameraNode)

		// place the camera
		cameraNode.position = SCNVector3(x: 0, y: 0, z: 15)

		// set the scene to the view
		self.gameView!.scene = scene

		// allows the user to manipulate the camera
		self.gameView!.allowsCameraControl = true

		loadSteps()
		cricketSource.loops = true
		ambientSource.loops = true
		ambientSource.isPositional = false
		scene.rootNode.addChildNode(cricket)
		scene.rootNode.addChildNode(ambient)
		scene.rootNode.addChildNode(chime)
		cricket.position = SCNVector3(x: 10.0, y: 0.0, z: -10.0)
		chime.position = SCNVector3(x: -5.0, y: 0.0, z: -15.0)

		cricket.addAudioPlayer(SCNAudioPlayer(source: cricketSource))
		ambient.addAudioPlayer(SCNAudioPlayer(source: ambientSource))
		chime.addAudioPlayer(SCNAudioPlayer(source: chimeSource))
		gameView.delegate = self
gameView.isPlaying = true
	}

	var stepinterval:TimeInterval = 0.5
	var lastInterval = CACurrentMediaTime()
	var isMoving = false
	func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
		cameraNode.position = cameraNode.position + SCNVector3(x: CGFloat(direction.x*0.3), y: 0.0, z: CGFloat(direction.y*0.3))
		direction = float2(x: 0.0, y: 0.0)
		if isMoving{
		if CACurrentMediaTime() - lastInterval > stepinterval{
		lastInterval = CACurrentMediaTime()
		cameraNode.addAudioPlayer(SCNAudioPlayer(source: steps[Int(arc4random_uniform(UInt32(10)))]))
		}
		}else{
		return
		}
	}

	func renderer(_ renderer: SCNSceneRenderer, didRenderScene scene: SCNScene, atTime time: TimeInterval) {

	}

	override func keyDown(with event: NSEvent) {
		if let move = Arrow(rawValue: event.keyCode) {
			isMoving = true
			direction = float2(0.0, 0.0) + move.vector
		}
	}

	override func keyUp(with event: NSEvent) {
		isMoving = false
		direction = float2(0.0, 0.0)
	}
}

func +(left: SCNVector3, right: SCNVector3)->SCNVector3{
	return SCNVector3(x: left.x + right.x, y: left.y, z: left.z + right.z)
}
