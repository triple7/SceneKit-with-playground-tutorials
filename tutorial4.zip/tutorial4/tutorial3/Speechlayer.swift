//
//  Speechlayer.swift
//  tutorial3
//
//  Created by Yuma Antoine Decaux on 22/07/17.
//  Copyright © 2017 antoxicon. All rights reserved.
//

import Foundation
import Cocoa
import SceneKit

let dataPath = "\(NSHomeDirectory())/Music"

extension GameViewController:NSSpeechSynthesizerDelegate
{

	func speechSynthesizer(_ sender: NSSpeechSynthesizer, didFinishSpeaking finishedSpeaking: Bool) {
		playSpeak()
}
}
		extension NSSpeechSynthesizer{
	func speak(_ text: String){
		url = Foundation.URL(fileURLWithPath: "\(dataPath)/\(text).aiff")
		startSpeaking(text, to: url!)
	}
}
