//
//  Assets.swift
//  tutorial2
//
//  Created by Yuma Antoine Decaux on 14/07/17.
//  Copyright © 2017 antoxicon. All rights reserved.
//

import SceneKit

var steps = [SCNAudioSource]()
var url:URL?
var speeches = [String]()
var currentSpeech = 0

func loadSteps(){
	for i in 1...10{
		let source = SCNAudioSource(fileNamed: "woodBare_\(i).mp3")!
		source.loops = false
		source.volume = 0.5
		steps.append(source)
	}
}

func loadSpeech(){
	let directory = Foundation.URL(fileURLWithPath: "\(dataPath)/speech.txt")
	print(directory.absoluteString)
	do{
		let text = try String(contentsOf: directory)
		let lines = text.components(separatedBy: "\n")
		for item in lines{
			print(item)
speeches.append(item)
		}
	}catch{
print("couldn't find file")
	}
}
