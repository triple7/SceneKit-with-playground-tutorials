//
//  AudioLayer.swift
//  tutorial4
//
//  Created by Yuma Antoine Decaux on 24/07/17.
//  Copyright © 2017 antoxicon. All rights reserved.
//

import Foundation
import AVFoundation
import SceneKit
import Cocoa

extension GameViewController{

	func wireSystem(){
		speakPlayer = AVAudioPlayerNode()
				let format = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: 16200, channels: 1, interleaved: false)
		environment = gameView.audioEnvironmentNode
		environment!.renderingAlgorithm = .HRTF
environment!.reverbParameters.loadFactoryReverbPreset(.largeRoom)
		//Configure the effects
distortion.loadFactoryPreset(.multiCellphoneConcert)
		distortion.wetDryMix = 20.0
		echo.delayTime = 0.5
echo.wetDryMix = 20.0
		//Start adding audio unit effects
engine!.attach(distortion)
		engine!.attach(echo)
mixer = engine!.mainMixerNode
		engine!.attach(speakPlayer!)

		engine!.connect(speakPlayer!, to: distortion, format: format)
		engine!.connect(distortion, to: echo, format: format)
				engine!.connect(echo, to: environment!, format: format)
	}

	func loadSpeak()->AVAudioPCMBuffer{
		do{
			let soundFile = try AVAudioFile(forReading: url!, commonFormat: AVAudioCommonFormat.pcmFormatFloat32, interleaved: false)
			speakBuffer = AVAudioPCMBuffer(pcmFormat: soundFile.processingFormat, frameCapacity: AVAudioFrameCount(soundFile.length))
				try soundFile.read(into: self.speakBuffer!)
		}catch{
		}
		return speakBuffer!
	}

	func playSpeak(){
		speakBuffer = loadSpeak()
		speakPlayer!.scheduleBuffer(self.speakBuffer!, at: nil, options: AVAudioPlayerNodeBufferOptions.interrupts, completionHandler: {()-> Void in
			currentSpeech = (currentSpeech + 1) % speeches.count
			self.speech.speak(speeches[currentSpeech])
		})
		speakPlayer!.play()
	}

}


func -(left: SCNVector3, right: SCNVector3)->AVAudio3DPoint{
	return AVAudio3DPoint(x: Float(left.x - right.x), y: Float(left.y - right.y), z: Float(left.z - right.z))
}
