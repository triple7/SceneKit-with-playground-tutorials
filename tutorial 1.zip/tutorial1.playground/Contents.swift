//: Playground - noun: a place where people can play

import SceneKit
import PlaygroundSupport

let scene = SCNScene()
let view = SCNView(frame: NSRect(x: 0.0, y: 0.0, width: 400.0, height: 400.0))
view.isAccessibilityEnabled()
view.autoenablesDefaultLighting = true
view.scene = scene

let hangNode = SCNNode()
var source = SCNAudioSource(fileNamed: "hanged.mp3")!
	source.loops = true
source.volume = 50.0
	source.load()
scene.rootNode.addChildNode(hangNode)
let player = SCNAudioPlayer(source: source)
hangNode.addAudioPlayer(player)
hangNode.position = SCNVector3(x: -5.0, y: 0.0, z: 0.0)

PlaygroundPage.current.liveView = view

let crickets = SCNNode()
let sourceCrickets = SCNAudioSource(fileNamed: "crickets.mp3")!
sourceCrickets.loops = true
sourceCrickets.load()
scene.rootNode.addChildNode(crickets)
let cricketsPlayer = SCNAudioPlayer(source: sourceCrickets)
crickets.position = SCNVector3(x: 3.0, y: 0.0, z: -10.0)
crickets.addAudioPlayer(cricketsPlayer)


let night = SCNNode()
let nightSource = SCNAudioSource(fileNamed: "night.mp3")!
nightSource.loops = true
nightSource.volume = 30.0
let nightPlayer = SCNAudioPlayer(source: nightSource)
scene.rootNode.addChildNode(night)
night.position = SCNVector3(x: -5.0, y: 0.0, z: -15.0)
night.addAudioPlayer(nightPlayer)
