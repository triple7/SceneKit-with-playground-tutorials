//
//  AudioLayer.swift
//  tutorial4
//
//  Created by Yuma Antoine Decaux on 24/07/17.
//  Copyright © 2017 antoxicon. All rights reserved.
//

import Foundation
import AVFoundation
import SceneKit
import Cocoa

extension GameViewController{

	func wireSystem(){
		environment = gameView.audioEnvironmentNode
		environment!.renderingAlgorithm = .HRTF
environment!.reverbParameters.loadFactoryReverbPreset(.largeRoom)
		//Configure the effects
	}

}
