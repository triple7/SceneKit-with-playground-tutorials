//
//  Assets.swift
//  tutorial2
//
//  Created by Yuma Antoine Decaux on 14/07/17.
//  Copyright © 2017 antoxicon. All rights reserved.
//

import SceneKit

let dataPath = "\(NSHomeDirectory())/Music/tutorial6/"
var url:URL?
var comics = [[SCNAudioSource]]()
var comicIndices = [(_jokeCount: Int, _introCount: Int, _outroCount: Int)]()
var comicNames = [String]()
var laughters = [[SCNAudioSource]]()
var laughterIndices = [Int]()
var barSounds = [SCNAudioSource]()
var claps = [SCNAudioSource]()

func loadSources(){
    let directory = Foundation.URL(fileURLWithPath: "\(dataPath)comics")
    do{
        print("comics directory is : \(directory.path)")
let folders = try FileManager.default.contentsOfDirectory(atPath: directory.path)
        for comic in folders{
            var audioFiles:[SCNAudioSource]!
            var audioFileCount:Int!
            if !comic.contains("_"){
                print(comic)
                comicNames.append(comic)
    let sources = Foundation.URL(fileURLWithPath: "\(dataPath)comics/\(comic)/jokes")
                print(sources)
                audioFiles = getSources(url: sources.path)
                audioFileCount = (audioFiles.count - 1)
            }else{
                continue
            }
            let introSources = Foundation.URL(fileURLWithPath: "\(dataPath)comics/\(comic)/intro")
            let intros = getSources(url: introSources.path)
            let introCount = (intros.count - 1)
            audioFiles = audioFiles + intros
            
            let outroSources = Foundation.URL(fileURLWithPath: "\(dataPath)comics/\(comic)/outro")
            let outros = getSources(url: outroSources.path)
            let outroCount = (outros.count - 1)
            audioFiles = audioFiles +  outros
            comics.append(audioFiles)
            comicIndices.append((audioFileCount, introCount, outroCount))
        }

        //Start loading laughing sounds
            let laughDirectory = Foundation.URL(fileURLWithPath: "\(dataPath)laughters")
        print(laughDirectory.path)
        let laughterFolders = try FileManager.default.contentsOfDirectory(atPath: laughDirectory.path)
        for folder in laughterFolders{
            if !folder.contains("_"){
let laughFolder = "\(laughDirectory.path)/\(folder)"
            print(laughFolder)
            let sources = getSources(url: laughFolder)
            let sourceCount = sources.count - 1
            laughters.append(sources)
            laughterIndices.append(sourceCount)
            }else{
                continue
            }
        }
    }catch{
            print("No such directory")
        }
}

    func getSources(url: String)->[SCNAudioSource]{
        var sources = [SCNAudioSource]()
        do{
        let audioFiles = try FileManager.default.contentsOfDirectory(atPath: url)
        for file in audioFiles{
            let path = Foundation.URL(fileURLWithPath: "\(url)folder")
            let source = SCNAudioSource(url: path)!
            source.loops = false
            source.isPositional = true
            source.volume = 3.0
            sources.append(source)
            }
            }catch{
                print("Directory not found")
            }
        return sources
    }
    
