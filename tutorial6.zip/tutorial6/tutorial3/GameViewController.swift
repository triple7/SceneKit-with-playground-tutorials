//
//  GameViewController.swift
//  tutorial3
//
//  Created by Yuma Antoine Decaux on 13/07/17.
//  Copyright (c) 2017 antoxicon. All rights reserved.
//

import SceneKit
import Cocoa
import AVFoundation

enum Arrow:UInt16{
	case Down = 125
	case UP = 126
	case Left = 123
	case Right = 124

	var vector:float2{
		switch self{
		case .Down: return float2(0, 1)
		case .UP: return float2(0, -1)
		case .Left: return float2(-1, 0)
		case .Right: return float2(1, 0)
		}
	}
}

class GameViewController: NSViewController, SCNSceneRendererDelegate {
	var direction = float2(0, 0)
	let cameraNode = SCNNode()
	@IBOutlet weak var gameView: GameView!
    
    let scene = SCNScene()
    //Non dynamic nodes
    let comic = SCNNode()
    let bar = SCNNode()

	//Audio engine component
	var engine:AVAudioEngine?
	var environment:AVAudioEnvironmentNode?
    
	override func awakeFromNib(){
		super.awakeFromNib()

        //Start loading assets
        loadSources()
        
		// create and add a camera to the scene
		cameraNode.camera = SCNCamera()
        cameraNode.name = "Camera"
		scene.rootNode.addChildNode(cameraNode)

		// place the camera
		cameraNode.position = SCNVector3(x: 0, y: 0, z: 0.0)

        //Place non dynamic nodes
        scene.rootNode.addChildNode(comic)
        scene.rootNode.addChildNode(bar)
        comic.position = SCNVector3(x: 0.0, y: 0.0, z: -10.0)
        comic.name = "comic"
        bar.position = SCNVector3(x: -10.0, y: 0.0, z: 5.0)
        bar.name = "bar"
        let centerNode = SCNNode()
        centerNode.name = "Center"
        scene.rootNode.addChildNode(centerNode)
        centerNode.position = SCNVector3(x: 0.0, y: 0.0, z: -5.0)

        createTables(node: centerNode, guests: 5, tableDiameter: 2.0)
        

		// set the scene to the view
		self.gameView!.scene = scene

		// allows the user to manipulate the camera
		self.gameView!.allowsCameraControl = true
		gameView.delegate = self
		gameView.isPlaying = true

		engine = gameView.audioEngine
    }

	var isEnvironment = false{
		didSet{
			if isEnvironment{
				wireSystem()
                introduce()
			}
		}
	}
	var mixer:AVAudioMixerNode?
	func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
		cameraNode.position = cameraNode.position + SCNVector3(x: CGFloat(direction.x*0.3), y: 0.0, z: CGFloat(direction.y*0.3))
		direction = float2(x: 0.0, y: 0.0)
	}

	func renderer(_ renderer: SCNSceneRenderer, didRenderScene scene: SCNScene, atTime time: TimeInterval) {
		if !isEnvironment{
			isEnvironment = true
		}
	}

	override func keyDown(with event: NSEvent) {
		if let move = Arrow(rawValue: event.keyCode) {
				direction = float2(0.0, 0.0) + move.vector
		}else{
interpretKeyEvents([event])
		}
	}

	override func insertNewline(_ sender: Any?) {
	}

	override func keyUp(with event: NSEvent) {
		direction = float2(0.0, 0.0)
	}
    
    //Mark: Scene setup methods
    
    var crowd = [SCNNode]()
    var crowdCount = 0
    let crowdPercent:Float = 0.25
    func createTables(node: SCNNode, guests: Int, tableDiameter: CGFloat){
        let count = laughters.count
        let degrees = 360/guests
        let nodePosition = node.position
        for i in 1...guests{
            let chair = SCNNode()
            chair.name = String(Int(arc4random_uniform(UInt32(count))))
            let name = chair.name!
            node.addChildNode(chair)
            chair.position = nodePosition + SCNVector3(x: (tableDiameter/2)*cos(CGFloat(Double(i*degrees)*Double.pi/180)), y: 0.0, z: (tableDiameter/2)*sin(CGFloat(Double(i*degrees)*Double.pi/180)))
            crowd.append(node.childNode(withName: name, recursively: true)!)
        }
        crowdCount += crowd.count
    }
    
    //Mark: Behavior for comic and laughing crowd 
    
    func introduce(){
        print("Introduction")
         comicIndex = comicNames.index(of: currentComic)!
        jokeCount = comicIndices[comicIndex]._jokeCount
        let player = SCNAudioPlayer(source: comics[comicIndex][jokeCount + Int(arc4random_uniform(UInt32(comicIndices[comicIndex]._introCount)))])
        player.didFinishPlayback = {
            self.generateApplause()
        }
        comic.addAudioPlayer(player)
    }
    
    var currentComic = "boue"
    var comicIndex = 0
    var jokeCount = 0
    var currentJoke = 0
    func joke(){
        print("Joking")
        if finishedLaughing < Int(arc4random_uniform(UInt32(Int(Float(crowdCount)/crowdPercent)))){
            if currentJoke < jokeCount {
                print("Jokes left")
            let player = SCNAudioPlayer(source: comics[comicIndex][currentJoke])
                player.didFinishPlayback = {
                    self.reactToJoke()
                }
            currentJoke += 1
            comic.addAudioPlayer(player)
            }else{
                self.outro()
            }
        }else{
            self.joke()
        }
    }
    
    var finishedLaughing = 0
    func reactToJoke(){
        for guest in crowd{
            finishedLaughing += 1
            let random = Int(arc4random_uniform(UInt32(100)))
            print(" mood is \(random)")
            if random > 75{
let player = generateLaughter(guest: guest)
                player.didFinishPlayback = {
                    let secondary = self.generateLaughter(guest: guest)
                    guest.addAudioPlayer(secondary)
                    secondary.didFinishPlayback = {
                        self.finishedLaughing -= 1
                    }
                }
                guest.addAudioPlayer(player)
            }else if random > 50{
                let player = generateLaughter(guest: guest)
                player.didFinishPlayback = {
                    self.finishedLaughing -= 1
                }
                guest.addAudioPlayer(player)
            }else{
                let player = generateShock(guest: guest)
                player.didFinishPlayback = {
                    self.finishedLaughing -= 1
                }
                guest.addAudioPlayer(player)
            }
        }
    }

    func generateApplause(){
        joke()
    }
    
    func generateLaughter(guest: SCNNode)->SCNAudioPlayer{
        let index = Int(guest.name!)!
                        let player = SCNAudioPlayer(source: laughters[index][Int(arc4random_uniform(UInt32(laughterIndices[index])))])
        return player
    }

    func generateShock(guest: SCNNode)->SCNAudioPlayer{
        return SCNAudioPlayer(source: laughters[Int(guest.name!)!][0])
    }
    
    func outro(){
        let player = SCNAudioPlayer(source: comics[comicIndex][comicIndices[comicIndex]._jokeCount + Int(arc4random_uniform(UInt32(comicIndices[comicIndex]._outroCount)))])
        player.didFinishPlayback = {
            self.applause()
        }
    }
    
    func applause(){
        
    }
    
}

func +(left: SCNVector3, right: SCNVector3)->SCNVector3{
	return SCNVector3(x: left.x + right.x, y: left.y, z: left.z + right.z)
}
