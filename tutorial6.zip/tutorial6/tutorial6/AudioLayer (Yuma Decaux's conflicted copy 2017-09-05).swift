//
//  AudioLayer.swift
//  tutorial4
//
//  Created by Yuma Antoine Decaux on 24/07/17.
//  Copyright © 2017 antoxicon. All rights reserved.
//

import Foundation
import AVFoundation
import SceneKit
import Cocoa

extension GameViewController{
    
    func wireSystem(){
        environment = gameView.audioEnvironmentNode
        environment!.renderingAlgorithm = .HRTF
        environment!.reverbParameters.loadFactoryReverbPreset(.largeHall)
        environment?.reverbBlend = 100.0
        environment?.reverbParameters.enable = true
        
        //Attach the distortion to the mixer
        //Configure the effects
        distortion.loadFactoryPreset(.multiBrokenSpeaker)
        distortion.wetDryMix = 0.0
print("output is: \(engine!.outputNode.outputFormat(forBus: 0).channelCount)")
        //Start adding audio unit effects
        engine!.attach(distortion)
        mixer = engine!.mainMixerNode
        engine?.stop()
        engine?.connect(mixer!, to: distortion, format: mixer!.outputFormat(forBus: 0))
                engine?.connect(distortion, to: engine!.outputNode, format: mixer!.outputFormat(forBus: 0))
        do{
        try engine?.start()
        }catch{
            print("Problem starting engine")
        }
    }
    
    func constructOutputFormatForEnvironment()->AVAudioFormat{
        var environmentOutputFormat:AVAudioFormat!
        var outputChannels = engine!.outputNode.outputFormat(forBus: 0).channelCount
        let sampleRate = engine!.outputNode.outputFormat(forBus: 0).sampleRate
        if outputChannels > 2 && outputChannels != 3{
            if outputChannels > 8{
                outputChannels = 8
            }
            var outputLayoutTag:AudioChannelLayoutTag!
            switch outputChannels{
            case 4:
                outputLayoutTag = kAudioChannelLayoutTag_AudioUnit_4
            break
            case 5:
                outputLayoutTag = kAudioChannelLayoutTag_AudioUnit_5
                break
            case 6:
                outputLayoutTag = kAudioChannelLayoutTag_AudioUnit_6
                break
            case 7:
                outputLayoutTag = kAudioChannelLayoutTag_AudioUnit_7_0
                break
            case 8:
                outputLayoutTag = kAudioChannelLayoutTag_AudioUnit_8
                break
            default:
                outputLayoutTag = kAudioChannelLayoutTag_Stereo
                break
            }

            let environmentChannelOutput = AVAudioChannelLayout(layoutTag: outputLayoutTag)
            environmentOutputFormat = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channelLayout: environmentChannelOutput)
        }else{
                        environmentOutputFormat = AVAudioFormat(standardFormatWithSampleRate: sampleRate, channelLayout: AVAudioChannelLayout.init(layoutTag: kAudioChannelLayoutTag_Stereo))
        }
        return environmentOutputFormat
    }
    
    
}
