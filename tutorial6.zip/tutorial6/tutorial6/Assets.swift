//
//  Assets.swift
//  tutorial2
//
//  Created by Yuma Antoine Decaux on 14/07/17.
//  Copyright © 2017 antoxicon. All rights reserved.
//

import SceneKit
import AVFoundation

let dataPath = "\(NSHomeDirectory())/Music/tutorial6/"
var url:URL?
var intros = [[SCNAudioSource]]()
var outros = [[SCNAudioSource]]()
var comics = [[SCNAudioSource]]()
var comicIndices = [(_jokeCount: Int, _introCount: Int, _outroCount: Int)]()
var jokeTimes = [[Float64]]()
var comicNames = [String]()
var laughters = [[SCNAudioSource]]()
var laughterIndices = [Int]()
var barSounds = [SCNAudioSource]()
var barCount = 0
var clapSounds = [SCNAudioSource]()
var clapCount = 0
var moveSounds = [[SCNAudioSource]]()
var moveCount = [Int]()
var moveSpeed = [0.6, 1.2]
var micSounds = [SCNAudioSource]()
var micCount = 0
var cockTailSounds = [SCNAudioSource]()
var cockTailCount = 0
var crowds = [SCNAudioSource]()

func loadSources(){
    let directory = Foundation.URL(fileURLWithPath: "\(dataPath)comics")
    do{
        print("comics directory is : \(directory.path)")
        let folders = try FileManager.default.contentsOfDirectory(atPath: directory.path)
        for comic in folders{
            var audioFiles:[SCNAudioSource]!
            var audioFileCount:Int!
            if !comic.contains("_"){
                comicNames.append(comic)
                let sources = Foundation.URL(fileURLWithPath: "\(dataPath)comics/\(comic)/jokes")
                audioFiles = getSources(url: sources.path, 18.0, true)
                audioFileCount = (audioFiles.count - 1)
            }else{
                continue
            }
            let introSources = Foundation.URL(fileURLWithPath: "\(dataPath)comics/\(comic)/intro")
            let intro = getSources(url: introSources.path, 15.0)
            let introCount = (intro.count - 1)
            
            let outroSources = Foundation.URL(fileURLWithPath: "\(dataPath)comics/\(comic)/outro")
            let outro = getSources(url: outroSources.path, 15.0)
            let outroCount = (outro.count - 1)
            
            let moveSources = Foundation.URL(fileURLWithPath: "\(dataPath)comics/\(comic)/move")
            let moves = getSources(url: moveSources.path, 3.0)
            let movesCount = (moves.count - 1)

            comics.append(audioFiles)
intros.append(intro)
            outros.append(outro)
            moveSounds.append(moves)
            moveCount.append(movesCount)
            
            comicIndices.append((audioFileCount, introCount, outroCount))
        }

        //Load bar sounds
        let barDirectory = Foundation.URL(fileURLWithPath: "\(dataPath)bar")
        barSounds = getSources(url: barDirectory.path)
        barCount = barSounds.count - 1
        
        //Load clapping sounds
        let clapDirectory = Foundation.URL(fileURLWithPath: "\(dataPath)claps")
        clapSounds = getSources(url: clapDirectory.path, 2.0)
        clapCount = clapSounds.count - 1

        //Load mic sounds
        let micDirectory = Foundation.URL(fileURLWithPath: "\(dataPath)mic")
        micSounds = getSources(url: micDirectory.path, 30.0)
        micCount = micSounds.count - 1
        //Load cocktail sounds
        let cocktailDirectory = Foundation.URL(fileURLWithPath: "\(dataPath)cocktail")
        cockTailSounds = getSources(url: cocktailDirectory.path, 2.0)
        cockTailCount = cockTailSounds.count - 1

        //Load crowd ambience files
        let crowdDirectory = Foundation.URL(fileURLWithPath: "\(dataPath)crowd")
        crowds = getSources(url: crowdDirectory.path, 8.0)
        
        //Load laughing sounds
        let laughDirectory = Foundation.URL(fileURLWithPath: "\(dataPath)laughters")
        let laughterFolders = try FileManager.default.contentsOfDirectory(atPath: laughDirectory.path)
        for folder in laughterFolders{
            if !folder.contains("_"){
                let laughFolder = "\(laughDirectory.path)/\(folder)"
                let sources = getSources(url: laughFolder)
                let sourceCount = sources.count - 1
                laughters.append(sources)
                laughterIndices.append(sourceCount)
            }else{
                continue
            }
        }
    }catch{
        print("No such directory")
    }
}

func getSources(url: String, _ volume: Float = 2.0, _ comic: Bool = false)->[SCNAudioSource]{
    var sources = [SCNAudioSource]()
    var times = [Float64]()
    do{
        let audioFiles = try FileManager.default.contentsOfDirectory(atPath: url)
        for file in audioFiles{
            let path = Foundation.URL(fileURLWithPath: "\(url)/\(file)")
            if comic{
                let time = AVURLAsset(url: path)
                let duration = CMTimeGetSeconds(time.duration)
                times.append(duration)
            }
            let source = SCNAudioSource(url: path)!
            source.loops = false
            source.isPositional = true
            source.volume = volume
            //source.load()
            sources.append(source)
        }
        if comic{
            jokeTimes.append(times)
        }
    }catch{
        print("Directory not found")
    }
    return sources
}

func randomise(_ value: Int)->Int{
    return Int(arc4random_uniform(UInt32(value)))
}

func delay(_ delay: Double, closure: @escaping ()->()) {
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + Double(Int64(delay*Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC), execute: closure)
}

