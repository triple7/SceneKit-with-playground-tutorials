//
//  GameViewController.swift
//  tutorial3
//
//  Created by Yuma Antoine Decaux on 13/07/17.
//  Copyright (c) 2017 antoxicon. All rights reserved.
//

import SceneKit
import Cocoa
import AVFoundation
import QuartzCore

enum Arrow:UInt16{
    case Down = 125
    case UP = 126
    case Left = 123
    case Right = 124
    
    var vector:float2{
        switch self{
        case .Down: return float2(0, 1)
        case .UP: return float2(0, -1)
        case .Left: return float2(-1, 0)
        case .Right: return float2(1, 0)
        }
    }
}

class GameViewController: NSViewController, SCNSceneRendererDelegate {
    var direction = float2(0, 0)
    let cameraNode = SCNNode()
    @IBOutlet weak var gameView: GameView!
    
    let scene = SCNScene()
    //Non dynamic nodes
    let comic = SCNNode()
    let bar = SCNNode()
    let crowd1 = SCNNode()
    let crowd2 = SCNNode()
    
    //Audio engine component
    var engine:AVAudioEngine?
    var environment:AVAudioEnvironmentNode?
    let distortion = AVAudioUnitDistortion()
    
    

    override func awakeFromNib(){
        super.awakeFromNib()
        
        //Start loading assets
        loadSources()
        currentComic = comicNames[0]
        comicIndex = 0
        
        
        // create and add a camera to the scene
        cameraNode.camera = SCNCamera()
        cameraNode.name = "Camera"
        scene.rootNode.addChildNode(cameraNode)
        
        // place the camera
        cameraNode.position = SCNVector3(x: 0, y: 0, z: 0.0)
        
        //Place non dynamic nodes
        scene.rootNode.addChildNode(comic)
        scene.rootNode.addChildNode(bar)
        comic.position = offStage
        comic.name = "comic"
        bar.position = SCNVector3(x: -15.0, y: 0.0, z: 5.0)
        bar.name = "bar"

        //Start adding all the guests
        positionTable(5, 2.5, -10.0, 0.0, -5.0)
                positionTable(5, 2.5, -10.0, 0.0, -12.0)
                positionTable(5, 2.5, -15.0, 0.0, -20.0)
                positionTable(5, 2.5, 10.0, 0.0, -5.0)
                positionTable(5, 2.5, 10.0, 0.0, -10.0)
                        positionTable(5, 2.5, 10.0, 0.0, -15.0)
                                positionTable(5, 2.5, 10.0, 0.0, -25.0)
                                        positionTable(5, 2.5, 0.0, 0.0, -5.0)
                                                positionTable(5, 2.5, 0.0, 0.0, -15.0)
        positionTable(5, 2.5, 0.0, 0.0, 5.0)
                positionTable(5, 2.5, -12.0, 0.0, 5.0)
                        positionTable(5, 2.5, 12.0, 0.0, 5.0)
                                positionTable(5, 2.5, 12.0, 0.0, 10.0)
                                        positionTable(5, 2.5, -12.0, 0.0, 10.0)
        
        //Start the ambience sounds
        scene.rootNode.addChildNode(crowd1)
        scene.rootNode.addChildNode(crowd2)
        crowd1.position = SCNVector3(x: -10.0, y: 0.0, z: -2.0)
        crowd2.position = SCNVector3(x: 8.0, y: 0.0, z: 2.0)
        crowd1Player = SCNAudioPlayer(source: crowds[0])
        crowd2Player = SCNAudioPlayer(source: crowds[1])
        
        crowd1Player!.audioSource!.loops = true
        crowd2Player!.audioSource!.loops = true

        
        // set the scene to the view
        self.gameView!.scene = scene

        // allows the user to manipulate the camera
        self.gameView!.allowsCameraControl = true
        gameView.delegate = self
        gameView.isPlaying = true
        
        engine = gameView.audioEngine
        
        

    }
    
    var isEnvironment = false{
        didSet{
            if isEnvironment{
                wireSystem()
            }
        }
    }
    var mixer:AVAudioMixerNode?
    var lastJokeTime:Float64 = 0.0
    var captureJokeTime = false
    var startTime = CACurrentMediaTime()
        var clapStartTime = CACurrentMediaTime()
    var started = true
    var moving = false
    var reachedMic = false
    var reachedOffStage = false
    let offStage = SCNVector3(x: 20.0, y: 0.0, z: -20.0)
    let micPos = SCNVector3(x: 0.0, y: 0.0, z: -35.0)
    var lastMoveTime = CACurrentMediaTime()
    var delta:CGFloat = 0.033
    var speed:CGFloat = 1.2
    var pokedMic = false
    func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        cameraNode.position = cameraNode.position + SCNVector3(x: CGFloat(direction.x*0.3), y: 0.0, z: CGFloat(direction.y*0.3))
        direction = float2(x: 0.0, y: 0.0)
    generateBarSound(barIntensity)
        generateCocktailSound()
        
        //Wait for a few seconds to start the intro to the first comic
        if started{
            if reachedMic{
                if !pokedMic{
                self.comic.addAudioPlayer(SCNAudioPlayer(source: micSounds[randomise(micCount)]))
                    pokedMic = true
                    delay(2.0){
self.introduce()
self.started = false
                    }
                }
            }else{
                if (micPos - comic.position).length < 0.5{
                    reachedMic = true
                    return
                }else{
                    var offset = micPos - comic.position
                    offset = offset.normalise
                    offset *= speed*delta
                    let newPosition = comic.position + offset
                    comic.position = newPosition
                    if CACurrentMediaTime() - lastMoveTime > moveSpeed[comicIndex]{
                        lastMoveTime = CACurrentMediaTime()
comic.addAudioPlayer(SCNAudioPlayer(source: moveSounds[comicIndex][randomise(moveCount[comicIndex])]))
                    }
                    return
                }
            }
        }
        
        if isLeaving{
            if (offStage - comic.position).length < 0.5{
                reachedOffStage = true
                self.swapComic()
                return
            }else{
                var offset = comic.position - micPos
                offset = offset.normalise
                offset *= speed*delta
                let newPosition = comic.position + offset
                comic.position = newPosition
                if CACurrentMediaTime() - lastMoveTime > moveSpeed[comicIndex]{
                    lastMoveTime = CACurrentMediaTime()
                    comic.addAudioPlayer(SCNAudioPlayer(source: moveSounds[comicIndex][randomise(moveCount[comicIndex])]))
                }
                return
            }
        }
        
        //Check joking and crowd states
        if !introFinished{
return
        }
    
        if self.crowdClapping{
                if CACurrentMediaTime() - self.clapStartTime > self.clapIntensity{
                    self.crowdClapping = false
                    self.joke()
                    return
                }
            }

        if self.crowdLaughing{
            //randomise(Int(Float(self.crowdCount)*self.crowdPercent))
            if self.finishedLaughing < 8 {
                if !self.isJoking{
                    self.crowdLaughing = false
                    self.joke()
                    return
                }
            }
        }
    
        if isJoking{
            if captureJokeTime{
                lastJokeTime = AVAudioTime.seconds(forHostTime: audioNode!.lastRenderTime!.hostTime)
                captureJokeTime = false
                return
            }
            let currentTime = AVAudioTime.seconds(forHostTime: audioNode!.lastRenderTime!.hostTime)
            if jokeTimes[comicIndex][currentJoke] - (currentTime - lastJokeTime) < Double(randomise(2))/100 {
                self.isJoking = false
                if !crowdLaughing{
                    self.reactToJoke()
                    return
                }
            }
        }
        
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didRenderScene scene: SCNScene, atTime time: TimeInterval) {
        if !isEnvironment{
            isEnvironment = true
            print("Starting to place crowd")
            crowd1.addAudioPlayer(crowd1Player!)
            crowd2.addAudioPlayer(crowd2Player!)

        }
    }
    //Mark: Scene setup methods
    
    func swapComic(){
        isLeaving = false
        introFinished = false
        comicIndex = (comicIndex + 1) % comics.count
        currentComic = comicNames[comicIndex]
        crowdLaughing = false
        crowdClapping = false
        delay(2.0){
            self.started = true
            self.reachedMic = false
            self.pokedMic = false
            self.jokeCount = 0
            self.currentJoke = 0
        }
    }
    
    func positionTable(_ guests: Int, _ tableDiameter: CGFloat, _ x: CGFloat, _ y: CGFloat, _ z: CGFloat){
        let node = SCNNode()
        node.position = SCNVector3(x: x, y: y, z: z)
        scene.rootNode.addChildNode(node)
        createTables(node: node, guests: guests, tableDiameter: tableDiameter)
    }
    
    var crowd = [SCNNode]()
    var crowdCount = 0
    let crowdPercent:Float = 0.25
    func createTables(node: SCNNode, guests: Int, tableDiameter: CGFloat){
        let count = laughters.count
        let degrees = 360/guests
        let nodePosition = node.position
        for i in 1...guests{
            let chair = SCNNode()
            chair.name = String(randomise(count))
            let name = chair.name!
            node.addChildNode(chair)
            chair.position = nodePosition + SCNVector3(x: (tableDiameter/2)*cos(CGFloat(Double(i*degrees)*Double.pi/180)), y: 0.0, z: (tableDiameter/2)*sin(CGFloat(Double(i*degrees)*Double.pi/180)))
            crowd.append(node.childNode(withName: name, recursively: true)!)
            clapCounts.append(0)
        }
        crowdCount += guests
    }
    
    //Mark: Behavior for comic and laughing crowd

    var introFinished = false
    func introduce(){
        dimCrowd(fadeOut: true)
        barIntensity = 1000
        comicIndex = comicNames.index(of: currentComic)!
        jokeCount = comicIndices[comicIndex]._jokeCount
        countClaps(20)
        let player = SCNAudioPlayer(source: intros[comicIndex][randomise(comicIndices[comicIndex]._introCount)])
        player.didFinishPlayback = {
            self.generateApplause(3.0)
        }
        comic.addAudioPlayer(player)
    }
    
    var currentComic = "boue"
    var comicIndex = 0
    var jokeCount = 0
    var currentJoke = 0
    var audioNode:AVAudioNode?
    var isJoking = false
    func joke(){
        DispatchQueue.main.async{
        self.isJoking = true
        self.captureJokeTime = true
            if self.currentJoke < self.jokeCount {
                print("joke \(self.currentJoke)")
                let player = SCNAudioPlayer(source: comics[self.comicIndex][self.currentJoke])
                self.audioNode = player.audioNode
                player.didFinishPlayback = {
                    self.finishedLaughing -= 1
                    self.countClaps()
                }
                self.currentJoke += 1
                self.comic.addAudioPlayer(player)
            }else{
                self.outro()
            }
        }
    }
    
    var finishedLaughing = 0
    var crowdLaughing = false
    func reactToJoke(){
        print("crowd about to laugh")
        crowdLaughing = true
        DispatchQueue.main.async{
        for guest in self.crowd{
            self.finishedLaughing += 1
            let random = randomise(100)
            if random > 75{
                let player = self.generateLaughter(guest: guest)
                player.didFinishPlayback = {
                    self.clap(self.crowd.index(of: guest)!)
                    self.finishedLaughing -= 1
                }
                guest.addAudioPlayer(player)
            }else if random > 50 && random < 75{
                let player = self.generateLaughter(guest: guest)
                player.didFinishPlayback = {
                    self.finishedLaughing -= 1
                }
                guest.addAudioPlayer(player)
            }else{
                self.finishedLaughing -= 1
            }
        }
        }
    }
    
    var crowdClapping = false
    var clapIntensity = 3.0
    func generateApplause( _ intensity: Double, _ intro: Bool = true){
        clapIntensity = intensity
        introFinished = intro
        crowdClapping = true
        DispatchQueue.main.async{
        for guest in self.crowd{
            delay(Double(randomise(200))/100.0){
            self.clap(self.crowd.index(of: guest)!)
            }
        }
        }
        clapStartTime = CACurrentMediaTime()
    }
    
    func generateLaughter(guest: SCNNode)->SCNAudioPlayer{
        let index = Int(guest.name!)!
        let player = SCNAudioPlayer(source: laughters[index][randomise(laughterIndices[index])])
        return player
    }
    
    func generateShock(guest: SCNNode)->SCNAudioPlayer{
        return SCNAudioPlayer(source: laughters[Int(guest.name!)!][0])
    }
    
    var isLeaving = false
    func outro(){
        let player = SCNAudioPlayer(source: outros[comicIndex][ randomise(comicIndices[comicIndex]._outroCount)])
        player.didFinishPlayback = {
            self.countClaps(15)
            self.isLeaving = true
            self.generateApplause(7.0)
        }
        comic.addAudioPlayer(player)
    }
    
    func clap(_ index: Int){
        let guest = crowd[index]
        let clapIndex = clapCounts[index]
        let player = SCNAudioPlayer(source: clapSounds[randomise(clapCount)])
        player.audioSource!.rate = 1 + Float(randomise(100))/100
        player.didFinishPlayback = {
            if clapIndex > 0{
                self.clapCounts[index] = clapIndex - 1
                self.clap(index)
            }
        }
        guest.addAudioPlayer(player)
    }

    var clapCounts = [Int]()
    func countClaps(_ factor: Int = 1){
        DispatchQueue.global(qos: .userInitiated).async{
            for i in 0 ... self.crowdCount - 1  {
                self.clapCounts[i] = randomise(factor*2)
            }
        }
    }
    
    var barIntensity = 1000
    func generateBarSound(_ value: Int){
        for guest in crowd{
                let random = randomise(value)
            if random < 1{
                guest.addAudioPlayer(SCNAudioPlayer(source: barSounds[randomise(barCount)]))
            }
        }
    }

    func generateCocktailSound(){
        let random = randomise(800)
        if random < 2 {
            bar.addAudioPlayer(SCNAudioPlayer(source: cockTailSounds[randomise(cockTailCount)]))
        }
    }
    
    var crowd1Player:SCNAudioPlayer?
    var crowd2Player:SCNAudioPlayer?
    func dimCrowd(fadeOut: Bool){
        SCNTransaction.begin()
        SCNTransaction.animationDuration = 2.0
        if fadeOut{
            print(crowd1Player!.audioSource!.volume)
            crowd1Player?.audioSource!.volume = 0.0
            crowd2Player?.audioSource!.volume = 0.0
        }else{
            crowd1Player?.audioSource!.volume = 5.0
            crowd2Player?.audioSource!.volume = 5.0
        }
        SCNTransaction.commit()
    }
    
    override func keyDown(with event: NSEvent) {
        if let move = Arrow(rawValue: event.keyCode) {
            direction = float2(0.0, 0.0) + move.vector
        }else{
            interpretKeyEvents([event])
        }
    }
    
    override func insertNewline(_ sender: Any?) {
    }
    
    override func keyUp(with event: NSEvent) {
        direction = float2(0.0, 0.0)
    }

    override func insertText(_ insertString: Any) {
        let str = insertString as! String
        switch str{
        case " ":
cameraNode.addAudioPlayer(SCNAudioPlayer(source: clapSounds[randomise(clapCount)]))
            case "a":
            self.reactToJoke()
            case "j": self.joke()
        default:
            break
        }
    }

}
