//
//  AppDelegate.swift
//  tutorial6
//
//  Created by Yuma Antoine Decaux on 25/8/17.
//  Copyright (c) 2017 Yuma Antoine Decaux. All rights reserved.
//

import Cocoa

@NSApplicationMain
class AppDelegate: NSObject, NSApplicationDelegate {
    
    @IBOutlet weak var window: NSWindow!
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        // Insert code here to initialize your application
    }
    
}
