//
//  VectorMath.swift
//  tutorial6
//
//  Created by Yuma Antoine Decaux on 28/8/17.
//  Copyright © 2017 Yuma Antoine Decaux. All rights reserved.
//

import SceneKit

func + (left: SCNVector3, right : SCNVector3) -> SCNVector3 { return SCNVector3(x: left.x + right.x, y: left.y  , z: left.z+right.z)
}

func - (left: SCNVector3, right : SCNVector3) -> SCNVector3 { return SCNVector3(x: left.x - right.x, y: left.y, z: left.z-right.z)
}

func += ( left: inout SCNVector3, right: SCNVector3) {
    left = left + right
}

func -= ( left: inout SCNVector3, right: SCNVector3) {
    left = left - right
}

func + (left: SCNVector3, right : CGFloat) -> SCNVector3 { return SCNVector3(x: left.x + right, y: left.y , z: left.z+right)
}

func - (left: SCNVector3, right : CGFloat) -> SCNVector3 { return SCNVector3(x: left.x - right, y: left.y , z: left.z-right)
}

func * (left: SCNVector3, right : CGFloat) -> SCNVector3 { return SCNVector3(x: left.x * right, y: left.y , z: left.z*right)
}

func / (left: SCNVector3, right: CGFloat) -> SCNVector3 { return SCNVector3(x: left.x/right, y: left.y, z: left.z/right)
}

func += ( left: inout SCNVector3, right: CGFloat) {
    left = left + right
}

func -= ( left: inout SCNVector3, right: CGFloat) {
    left = left - right
}

func *= ( left: inout SCNVector3, right: CGFloat) {
    left = left * right
}

func /= ( left: inout SCNVector3, right: CGFloat) {
    left = left / right
}

//Mark: distances, magnitudes and dot products

func distance(left: SCNVector3, right: SCNVector3)->CGFloat{
    return CGFloat(sqrt(pow(Double(left.x-right.x), 2)+pow(Double(left.y-right.y), 2)))
}

extension SCNVector3{
    var length:CGFloat{
        return sqrt(self.x*self.x+self.z*self.z)
    }
    
    var normalise:SCNVector3{
        return self/length
    }
    
    func dot(other: SCNVector3)->CGFloat{
        return self.x*other.x+self.z*other.z
    }
    
}
